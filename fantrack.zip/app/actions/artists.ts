"use server"

import { db } from "@/lib/db"
import { artist, follow } from "@/lib/db/schema"
import { getUserId } from "@/lib/session"
import { and, asc, eq, inArray } from "drizzle-orm"
import { revalidatePath } from "next/cache"

export type Artist = typeof artist.$inferSelect

/** All artists in the catalog, with a flag for whether the current user follows each. */
export async function getArtistsWithFollowState() {
  const userId = await getUserId()
  const [allArtists, myFollows] = await Promise.all([
    db.select().from(artist).orderBy(asc(artist.name)),
    db.select({ artistId: follow.artistId }).from(follow).where(eq(follow.userId, userId)),
  ])
  const followedIds = new Set(myFollows.map((f) => f.artistId))
  return allArtists.map((a) => ({ ...a, following: followedIds.has(a.id) }))
}

/** Artists the current user follows. */
export async function getFollowedArtists() {
  const userId = await getUserId()
  const myFollows = await db.select({ artistId: follow.artistId }).from(follow).where(eq(follow.userId, userId))
  const ids = myFollows.map((f) => f.artistId)
  if (ids.length === 0) return []
  return db.select().from(artist).where(inArray(artist.id, ids)).orderBy(asc(artist.name))
}

export async function getArtistBySlug(slug: string) {
  const userId = await getUserId()
  const [found] = await db.select().from(artist).where(eq(artist.slug, slug)).limit(1)
  if (!found) return null
  const [f] = await db
    .select()
    .from(follow)
    .where(and(eq(follow.userId, userId), eq(follow.artistId, found.id)))
    .limit(1)
  return { ...found, following: Boolean(f) }
}

export async function followArtist(artistId: number) {
  const userId = await getUserId()
  await db.insert(follow).values({ userId, artistId }).onConflictDoNothing()
  revalidatePath("/discover")
  revalidatePath("/")
}

export async function unfollowArtist(artistId: number) {
  const userId = await getUserId()
  await db.delete(follow).where(and(eq(follow.userId, userId), eq(follow.artistId, artistId)))
  revalidatePath("/discover")
  revalidatePath("/")
}
